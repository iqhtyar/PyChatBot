import telegram

def get_bard_response(message):
  """Mengirim permintaan ke Bard chat bot dan mengambil responsnya."""
  bot = telegram.Bot(token="5531116577:AAFtbN9V3-E2kdCfVKxxSjQ9Dv4IWi2aWiw")
  response = bot.send_message(chat_id=message.chat.id, text=message.text)
  return response.text

def handle_message(update, context):
  """Menangani pesan dari pengguna."""
  message = update.message.text
  response = get_bard_response(message)
  update.message.reply_text(response)

updater = telegram.Bot(token="5531116577:AAFtbN9V3-E2kdCfVKxxSjQ9Dv4IWi2aWiw")
updater.dispatcher.add_handler(telegram.MessageHandler(telegram.Filters.text, handle_message))
updater.start_polling()
updater.idle()
