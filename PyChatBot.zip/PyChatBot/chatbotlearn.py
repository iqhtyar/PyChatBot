import random
import os
import json

def greeting():
    responses = ["Halo! Ada yang bisa saya bantu?", "Hai, apa kabar?", "Selamat datang!"]
    return random.choice(responses)

def farewell():
    responses = ["Sampai jumpa lagi!", "Selamat tinggal. Semoga harimu menyenangkan.", "Hati-hati."]
    return random.choice(responses)

def respond(user_input, knowledge):
    if "nama" in user_input.lower():
        return "Saya adalah Chatbot, senang bertemu dengan Anda!"
    elif "apa kabar" in user_input.lower():
        return "Saya hanyalah program, tetapi terima kasih sudah bertanya. Bagaimana dengan Anda?"
    elif "keluar" in user_input.lower():
        return farewell()
    elif "tambah pengetahuan" in user_input.lower():
        return add_knowledge(user_input, knowledge)
    else:
        return "Saya tidak begitu mengerti. Bisa Anda jelaskan lebih lanjut?"

def add_knowledge(user_input, knowledge):
    new_knowledge = input("Apa yang seharusnya saya jawab untuk pertanyaan ini? ")
    question = user_input.replace("tambah pengetahuan", "").strip()
    
    knowledge[question] = new_knowledge
    save_knowledge(knowledge)
    
    return "Terima kasih atas kontribusi Anda. Pengetahuan saya telah diperbarui."

def save_knowledge(knowledge):
    with open("knowledge.json", "w") as file:
        json.dump(knowledge, file)

def load_knowledge():
    if os.path.exists("knowledge.json"):
        with open("knowledge.json", "r") as file:
            return json.load(file)
    else:
        return {}

def main():
    knowledge = load_knowledge()
    print(greeting())
    
    while True:
        user_input = input("Anda: ")
        if user_input.lower() == "keluar":
            print(farewell())
            break
        else:
            response = respond(user_input, knowledge)
            print("Chatbot:", response)

if __name__ == "__main__":
    main()
