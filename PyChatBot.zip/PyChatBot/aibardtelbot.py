import requests
from telegram.ext import Updater, 
CommandHandler

# Get your Telegram bot token from the BotFather
BOT_TOKEN = "5531116577:AAFtbN9V3-E2kdCfVKxxSjQ9Dv4IWi2aWiw"

# Initialize the Updater
updater = Updater(token=BOT_TOKEN)

# Define a command handler for the /bard command
def handle_bard(update, context):
    # Get the user's message
    message = update.message.text

    # Send a request to the Bard API
    response = requests.get("https://bard.ai/v1/generate",
                            params={"prompt": message})

    # Get the response from the Bard API
    result = response.json()

    # Send the response to the user
    update.message.reply_text(result["text"])

# Register the command handler
updater.dispatcher.add_handler(CommandHandler("bard", handle_bard))

# Start the Updater
updater.start_polling()

# Keep the Updater running
updater.idle()
