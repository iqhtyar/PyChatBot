from bard.models import Bard

def get_bard_response(message):
  """Mengirim permintaan ke Bard chat bot dan mengambil responsnya."""
  bard = Bard()
  response = bard.generate_response(message)
  return response

def handle_message(update, context):
  """Menangani pesan dari pengguna."""
  message = update.message.text
  response = get_bard_response(message)
  update.message.reply_text(response)

updater = Updater(token="5531116577:AAFtbN9V3-E2kdCfVKxxSjQ9Dv4IWi2aWiw")
updater.dispatcher.add_handler(CommandHandler("start", handle_message))
updater.start_polling()
updater.idle()
