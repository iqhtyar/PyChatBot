import random

# Definisikan kelas Chatbot
class Chatbot:

    def __init__(self):
        # Inisialisasi variabel
        self.responses = ["Halo!"]
        self.learned_responses = ["Maaf saya harus jawab apa ya!"]

    def generate_response(self, input_text):
        # Pilih respons secara acak
        return random.choice(self.responses)

def add_learned_response(self, response):
    self.learned_responses.append(response)

# Buat objek chatbot
chatbot = Chatbot()

# Mulai percakapan
while True:
    # Terima input dari pengguna
    input_text = input("?")

    # Generate respons dari chatbot
    response = chatbot.generate_response(input_text)

    # Tampilkan respons kepada pengguna
    print(response)
