import random

# Definisikan kelas Chatbot
class Chatbot:

    def __init__(self):
        # Inisialisasi variabel
        self.responses = ["Halo! Bagaimana kabarmu?", "Aku baik-baik saja, terima kasih. Bagaimana denganmu?", "Aku senang bisa berbicara denganmu."]

    def generate_response(self, input_text):
        # Pilih respons secara acak
        return random.choice(self.responses)

# Buat objek chatbot
chatbot = Chatbot()

# Mulai percakapan
while True:
    # Terima input dari pengguna
    input_text = input("Apa yang ingin kamu tanyakan?")

    # Generate respons dari chatbot
    response = chatbot.generate_response(input_text)

    # Tampilkan respons kepada pengguna
    print(response)
