import random

# Definisikan kelas Chatbot
class Chatbot:

    def __init__(self):
        # Inisialisasi variabel
        self.responses = ["Halo!", "Saya tidak tahu harus bilang apa."]
        self.learned_responses = []

    def generate_response(self, input_text):
        # Pilih respons secara acak dari daftar respons yang dipelajari
        if self.learned_responses:
            return random.choice(self.learned_responses)
        else:
            # Jika tidak ada respons yang dipelajari, gunakan daftar respons default
            return random.choice(self.responses)

    def ask_answer(self, question):
        # Minta jawaban dari pengguna
        answer = input("Saya harus jawab apa ya? " + question + "? ")

        # Tambahkan respons ke daftar respons yang dipelajari
        self.learned_responses.append(answer)

# Buat objek chatbot
chatbot = Chatbot()

# Mulai percakapan
while True:
    # Terima input dari pengguna
    input_text = input("^_^ ")
    # Generate respons dari chatbot
    response = chatbot.generate_response(input_text)

    # Tampilkan respons kepada pengguna
    print(response)

    # Jika pengguna menanyakan pertanyaan
    if "jawab" in input_text:
        # Panggil fungsi ask_answer
        chatbot.ask_answer(input_text.replace("jawab", ""))
