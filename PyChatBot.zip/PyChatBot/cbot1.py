import random

# Daftar pertanyaan dan jawaban
pertanyaan = {
    "apa kabar?": ["Baik, terima kasih!", "Saya baik-baik saja.", "Lagi sibuk nih!"],
    "siapa kamu?": ["Saya adalah chatbot AI.", "Nama saya adalah ChatBot.", "Saya adalah program komputer yang dapat membantu Anda."],
    "apa hobi kamu?": ["Saya tidak punya hobi.", "Hobi saya adalah membantu pengguna.", "Saya suka belajar hal baru."],
    "apa tanggal hari ini?": ["Maaf, saya tidak bisa memberitahu tanggal hari ini."],
    "selamat tinggal": ["Sampai jumpa!", "Selamat tinggal!", "Hati-hati!"]
}

# Fungsi untuk mendapatkan jawaban berdasarkan pertanyaan
def get_jawaban(pertanyaan, pertanyaan_user):
    jawaban = pertanyaan.get(pertanyaan_user)
    if jawaban:
        return random.choice(jawaban)
    else:
        return "Maaf, saya tidak mengerti pertanyaan Anda."

# Loop utama program
while True:
    pertanyaan_user = input("Anda: ")
    jawaban = get_jawaban(pertanyaan, pertanyaan_user)
    print("ChatBot:", jawaban)