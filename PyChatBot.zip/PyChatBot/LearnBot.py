import random

# Definisikan kelas Chatbot
class Chatbot:

    def __init__(self):
        # Inisialisasi variabel
        self.responses = ["Halo!", "Saya tidak tahu harus bilang apa."]
        self.learned_responses = []

    def generate_response(self, input_text):
        # Pilih respons secara acak dari daftar respons yang dipelajari
        if self.learned_responses:
            return random.choice(self.learned_responses)
        else:
            # Jika tidak ada respons yang dipelajari, gunakan daftar respons default
            return random.choice(self.responses)

    def ask_answer(self, question):
        # Minta jawaban dari pengguna
        answer = input("Saya harus jawab apa ya! " + question + "? ")

        # Tambahkan respons ke daftar respons yang dipelajari
        self.learned_responses.append(answer)

        # Simpan daftar respons ke file
        with open("learned_responses.txt", "w") as file:
            for response in self.learned_responses:
                file.write(response + "\n")

    def import_learned_responses(self):
        # Baca daftar respons dari file
        with open("learned_responses.txt", "r") as file:
            for response in file:
                self.learned_responses.append(response.strip())

# Buat objek chatbot
chatbot = Chatbot()

# Mulai percakapan
while True:
    # Terima input dari pengguna
    input_text = input("^_^ ")

    # Generate respons dari chatbot
    response = chatbot.generate_response(input_text)

    # Tampilkan respons kepada pengguna
    print(response)

    # Jika pengguna menanyakan pertanyaan
    if "jawaban" in input_text:
        # Panggil fungsi ask_answer
        chatbot.ask_answer(input_text.replace("jawaban", ""))

    # Jika chatbot di-restart
    if input_text == "import":
        chatbot.import_learned_responses()
