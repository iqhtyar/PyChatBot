import openai
import telegram
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters
openai.api_key = "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"

def generate_response(prompt):
    completions = openai.Completion.create(
        engine="text-davinci-002",
        prompt=prompt,
        max_tokens=1024,
        n=1,
        stop=None,
        temperature=0.5,
    )

    message = completions.choices[0].text
    return message.strip()
def handle_message(update, context):
    user_message = update.message.text
    response = generate_response(user_message)
    update.message.reply_text(response)
updater = Updater(token="5531116577:AAHSZLz_ApufX4a_xubcJ4G5uEshK7DiExE", use_context=True)
dispatcher = updater.dispatcher

message_handler = MessageHandler(Filters.text, handle_message)
dispatcher.add_handler(message_handler)

updater.start_polling()