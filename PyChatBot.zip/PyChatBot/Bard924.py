import google_bard
 
# Replace "YOUR_API_KEY" with the actual API Key obtained earlier
API_KEY = "YOUR_API_KEY"
 
def main():
    query = "What is the meaning of life?"
    response = google_bard.generate_text(query, api_key=API_KEY)
    print("Google Bard Response (Using google_bard Module):")
    print(response)
 
if __name__ == "__main__":
    main()
    
 import requests
import json
 
# Replace "YOUR_API_KEY" with the actual API Key obtained in Step 1
API_KEY = "YOUR_API_KEY"
URL = "https://bard.googleapis. 


def get_bard_response(query):
    response = requests.post(URL, headers=
                   {"Authorization": "Bearer " + API_KEY},
                             json={"query": query})
    data = json.loads(response.content)
    return data["text"]
    

def main():
    query = "Geeksforgeeks"
    response = get_bard_response(query)
    print("Google Bard Response:")
    print(response)
 
if __name__ == "__main__":
    main()
    
    

