import random

# Definisikan kelas Chatbot
class Chatbot:

    def __init__(self):
        # Inisialisasi variabel
        self.responses = ["@_@","-_-","*_*",">_<","0_0"]
        self.questions = []
        self.answers = []
        self.learned_responses = []

    def generate_response(self, input_text):
        # Pilih respons secara acak dari daftar respons yang dipelajari
        if self.learned_responses:
            return random.choice(self.learned_responses)
        else:
            # Jika tidak ada respons yang dipelajari, gunakan daftar respons default
            return random.choice(self.responses)

    def ask_answer(self, question):
        # Minta jawaban dari pengguna
        answer = input("Saya harus bilang apa ya! " + question + "? ")

        # Tambahkan respons ke daftar respons yang dipelajari
        self.learned_responses.append((question, answer))

        # Simpan pertanyaan dan jawaban ke file
        with open("questions.txt", "a") as file:
            file.write(question + "\n")
        with open("answers.txt", "a") as file:
            file.write(answer + "\n")

    def import_learned_responses(self):
        # Baca pertanyaan dari file
        with open("questions.txt", "r") as file:
            for question in file:
                self.questions.append(question.strip())

        # Baca jawaban dari file
        with open("answers.txt", "r") as file:
            for answer in file:
                self.answers.append(answer.strip())

# Buat objek chatbot
chatbot = Chatbot()

# Mulai percakapan
while True:
    # Terima input dari pengguna
    input_text = input("^_^ ")

    # Generate respons dari chatbot
    response = chatbot.generate_response(input_text)

    # Tampilkan respons kepada pengguna
    print(response)

    # Jika pengguna menanyakan pertanyaan
    if "jawaban" in input_text:
        # Panggil fungsi ask_answer
        chatbot.ask_answer(input_text.replace("jawaban", ""))

# Jika chatbot di-restart
if input_text == "import":
    chatbot.import_learned_responses()
