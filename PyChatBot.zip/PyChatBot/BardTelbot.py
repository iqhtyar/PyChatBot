import requests
from telegram.ext import Updater, CommandHandler

# Get your Telegram bot token from the BotFather
BOT_TOKEN = "5531116577:AAFtbN9V3-E2kdCfVKxxSjQ9Dv4IWi2aWiw"

# Create a new Updater object
updater = Updater(BOT_TOKEN)

# Define a command handler for the /start command
def start(update, context):
    # Send a message to the user
    update.message.reply_text("Hello! I am Bard, a large language model from Google AI. I can generate text, translate languages, write different kinds of creative content, and answer your questions in an informative way.")

# Add the command handler to the updater
updater.dispatcher.add_handler(CommandHandler("start", start))

# Start the updater
updater.start_polling()

# Keep the updater running until you press Ctrl+C
updater.idle()
